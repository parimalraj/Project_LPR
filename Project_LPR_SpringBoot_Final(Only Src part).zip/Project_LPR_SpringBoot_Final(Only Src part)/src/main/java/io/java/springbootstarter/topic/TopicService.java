package io.java.springbootstarter.topic;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.java.springbootstarter.model1.Topics1;
import io.java.springbootstarter.model2.Topics2;
import io.java.springbootstarter.model3.Topics3;
import io.java.springbootstarter.repository.Topics1.Topics1Repository;
import io.java.springbootstarter.repository.Topics2.Topics2Repository;
import io.java.springbootstarter.repository.Topics3.Topics3Repository;

@Service
public class TopicService {
	
	@Autowired
	private Topics1Repository topicRepo1;
	@Autowired
	private Topics2Repository topicRepo2;
	@Autowired
	private Topics3Repository topicRepo3;
	
	private String st1;
	private String st2;
	private String st3;
	
//	String st11;
//
//	public String getSt11() {
//		return st11;
//	}
//
//	public void setSt11(String st11) {
//		this.st11 = st11;
//	}

	ArrayList<Topic> topics = new ArrayList<Topic>(); 	
	
	public List<Topic> getAllTopics(){
		return topics;
	}
	
	public void addTopic(Topic topic) {
		topics.add(topic);
	}

	// TopicController t3=new TopicController();
	 

	 public List getByTopic(String id) {
		 
	  List al=new ArrayList<String>();
	  id=id.replaceAll("\\s","");
	  String[] s=id.split(",");

	  for(String h:s) {
		    
		  Optional<Topics1> str1 = (Optional<Topics1>)topicRepo1.findById(h);
			st1 = str1.get().getStatus1();
			System.out.println(st1);
			//st2 = str.get().getStatus2();
			//st3 = str.get().getStatus3();
			 Optional<Topics2> str2 = (Optional<Topics2>)topicRepo2.findById(h);
			 st2 = str2.get().getStatus2();
			 System.out.println(st2);
			 
			Optional<Topics3> str3 = (Optional<Topics3>)topicRepo3.findById(h);
			st3 = str3.get().getStatus3();

			 
			 
		  topics.add(new Topic(h,"complete",st1,st2,st3,st3)); 

	  		}
	  
	  for(String s2:s) {
	    al.add(topics.stream().filter(t -> t.getId().equalsIgnoreCase(s2)).findFirst().get());}
	  
	  return al; 
	  }


}
