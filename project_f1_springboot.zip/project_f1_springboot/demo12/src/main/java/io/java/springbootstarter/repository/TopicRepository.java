package io.java.springbootstarter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;



import io.java.springbootstarter.topic.Topics;

@Repository
public interface TopicRepository extends JpaRepository<Topics, String>{	
	
//	  @Query("SELECT status FROM project  WHERE id = 123")
//	   Topics findStatusById(@Param("id")String id);
	 
}
