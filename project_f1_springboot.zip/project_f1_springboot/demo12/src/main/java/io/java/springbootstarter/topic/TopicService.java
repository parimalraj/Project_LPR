package io.java.springbootstarter.topic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.capsule.taskmanager.model.Task;

import io.java.springbootstarter.repository.TopicRepository;


@Service
public class TopicService {
	
	@Autowired
	private TopicRepository topicRepo;
	private String st1;
	private String st2;
	private String st3;
	
	String st11;

	public String getSt11() {
		return st11;
	}

	public void setSt11(String st11) {
		this.st11 = st11;
	}

	ArrayList<Topic> topics = new ArrayList<Topic>(); 	
	
	public List<Topic> getAllTopics(){
		return topics;
	}
	
	public void addTopic(Topic topic) {
		topics.add(topic);
	}

	 TopicController t3=new TopicController();
	 
	 //public List getByTopic(String id,TopicService k) {
		 public List getByTopic(String id) {
	  List al=new ArrayList<String>();
	  id=id.replaceAll("\\s","");
	  String[] s=id.split(",");

	  for(String h:s) {
		    
		  Optional<Topics> str = (Optional<Topics>)topicRepo.findById(h);
			st1 = str.get().getStatus1();
			st2 = str.get().getStatus2();
			st3 = str.get().getStatus3();

		  topics.add(new Topic(h,"complete",st1,st2,st3,st3)); 

	  		}
	  
	  for(String s2:s) {
	    al.add(topics.stream().filter(t -> t.getId().equalsIgnoreCase(s2)).findFirst().get());}
	  
	  return al; 
	  }


}
